"use client"

import { useState } from "react"

interface ConflictItem {
  type: string
  state: number
  lookahead: string
  existing: {
    kind: string
    to?: number
    lhs?: string
    rhs?: string[]
    text?: string
  }
  new: {
    kind: string
    to?: number
    lhs?: string
    rhs?: string[]
    text?: string
  }
  state_items?: string[]
}

interface ConflictsDisplayProps {
  conflicts: ConflictItem[]
  conflictTexts?: string[]
}

const ConflictsDisplay = ({ conflicts, conflictTexts }: ConflictsDisplayProps) => {
  const [expandedConflict, setExpandedConflict] = useState<number | null>(null)

  const getConflictColor = (type: string) => {
    if (type.includes("Shift/Reduce")) return "bg-orange-50 border-orange-200"
    if (type.includes("Reduce/Reduce")) return "bg-red-50 border-red-200"
    return "bg-yellow-50 border-yellow-200"
  }

  const getActionDisplay = (action: any) => {
    if (action.kind === "shift") {
      return `Shift to state ${action.to}`
    }
    if (action.kind === "reduce") {
      return `Reduce by ${action.text}`
    }
    return action.kind
  }

  return (
    <div className="space-y-3">
      {conflicts.map((conflict, idx) => (
        <div key={idx} className={`border rounded-lg p-4 ${getConflictColor(conflict.type)}`}>
          <div className="flex items-start justify-between gap-4">
            <div className="flex-1">
              {conflictTexts && conflictTexts[idx] && (
                <div className="mb-3 p-2 bg-white rounded border border-gray-300">
                  <p className="text-xs font-mono text-gray-700">{conflictTexts[idx]}</p>
                </div>
              )}

              <div className="flex items-center gap-2 mb-2">
                <span className="font-bold text-sm text-gray-900">{conflict.type}</span>
                <span className="text-xs bg-gray-200 text-gray-800 px-2 py-1 rounded">State {conflict.state}</span>
                <span className="text-xs bg-blue-200 text-blue-800 px-2 py-1 rounded font-mono">
                  {conflict.lookahead}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-4 mt-3">
                <div className="bg-white rounded p-3 border border-gray-200">
                  <p className="text-xs font-semibold text-gray-600 mb-1">Existing Action</p>
                  <p className="text-sm font-mono text-gray-900">{getActionDisplay(conflict.existing)}</p>
                </div>
                <div className="bg-white rounded p-3 border border-gray-200">
                  <p className="text-xs font-semibold text-gray-600 mb-1">New Action</p>
                  <p className="text-sm font-mono text-gray-900">{getActionDisplay(conflict.new)}</p>
                </div>
              </div>

              {conflict.state_items && conflict.state_items.length > 0 && (
                <details className="mt-3 cursor-pointer">
                  <summary className="text-xs font-semibold text-gray-600 hover:text-gray-900">
                    View state items ({conflict.state_items.length})
                  </summary>
                  <div className="mt-2 bg-white rounded p-3 border border-gray-200 max-h-40 overflow-y-auto">
                    <ul className="space-y-1">
                      {conflict.state_items.map((item, itemIdx) => (
                        <li key={itemIdx} className="text-xs font-mono text-gray-700">
                          {item}
                        </li>
                      ))}
                    </ul>
                  </div>
                </details>
              )}
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}

export default ConflictsDisplay
