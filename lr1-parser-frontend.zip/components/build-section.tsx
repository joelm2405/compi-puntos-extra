"use client"

import { Textarea } from "@/components/ui/textarea"
import { useState } from "react"
import GrammarInfo from "@/components/grammar-info"
import StatesTable from "@/components/tables/states-table"
import TablesDisplay from "@/components/tables/tables-display"
import ClosureTable from "@/components/tables/closure-table"
import ConflictsDisplay from "@/components/conflicts-display"

interface BuildSectionProps {
  grammar: string
  setGrammar: (grammar: string) => void
  onBuildComplete: (grammar: string, data: any) => void
  buildResult?: any
}

const BuildSection = ({ grammar, setGrammar, onBuildComplete, buildResult }: BuildSectionProps) => {
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")

  const handleBuild = async () => {
    if (!grammar.trim()) return

    setLoading(true)
    setError("")
    console.log("[v0] Sending build request with grammar:", grammar)

    try {
      const response = await fetch("http://127.0.0.1:8000/build", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ grammar }),
        mode: "cors",
      })

      console.log("[v0] Build response status:", response.status)

      if (!response.ok) {
        throw new Error(`Server error: ${response.status}`)
      }

      const data = await response.json()
      console.log("[v0] Build data received:", data)

      onBuildComplete(grammar, data)
      setError("")
    } catch (err) {
      const errorMsg = err instanceof Error ? err.message : "Unknown error"
      console.error("[v0] Build error:", errorMsg)
      setError(`Error: ${errorMsg}`)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      <div className="space-y-3">
        <div>
          <label className="text-lg font-bold text-gray-900">Grammar Input</label>
          <p className="text-sm text-gray-600 mt-2">Enter your grammar rules (one per line, format: A → B C)</p>
        </div>
        <Textarea
          value={grammar}
          onChange={(e) => setGrammar(e.target.value)}
          placeholder="Enter your grammar rules here..."
          className="font-mono min-h-32"
        />
        {error && <p className="text-red-600 text-sm">{error}</p>}
        <button
          onClick={handleBuild}
          disabled={!grammar.trim() || loading}
          className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 text-white font-semibold py-2 px-4 rounded transition"
        >
          {loading ? "Building..." : "Build"}
        </button>
      </div>

      {buildResult && (
        <div className="space-y-6">
          {buildResult.is_lr1 === false && (
            <div className="bg-red-50 border-2 border-red-500 rounded-lg p-4">
              <div className="flex items-start gap-3">
                <div className="text-red-600 font-bold text-lg">⚠️</div>
                <div className="flex-1">
                  <h3 className="text-red-700 font-bold text-lg">Grammar is NOT LR(1)</h3>
                  <p className="text-red-600 text-sm mt-2">
                    This grammar has {buildResult.conflicts?.length || 0} conflict(s) and cannot be parsed with an LR(1)
                    parser.
                  </p>
                  {buildResult.conflicts_structured && buildResult.conflicts_structured.length > 0 && (
                    <div className="mt-4">
                      <ConflictsDisplay
                        conflicts={buildResult.conflicts_structured}
                        conflictTexts={buildResult.conflicts}
                      />
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {buildResult.is_lr1 === true && (
            <div className="bg-green-50 border-2 border-green-500 rounded-lg p-4">
              <div className="flex items-center gap-3">
                <div className="text-green-600 font-bold text-lg">✓</div>
                <div>
                  <h3 className="text-green-700 font-bold">Grammar is LR(1)</h3>
                  <p className="text-green-600 text-sm">
                    No conflicts detected. This grammar can be parsed with an LR(1) parser.
                  </p>
                </div>
              </div>
            </div>
          )}

          <GrammarInfo data={buildResult} />
          {buildResult.closure_table && <ClosureTable closureTable={buildResult.closure_table} />}
          <StatesTable states={buildResult.states} />
          <TablesDisplay tables={buildResult.tables} />
        </div>
      )}
    </div>
  )
}

export default BuildSection
