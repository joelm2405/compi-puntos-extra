import requests, json
url='http://127.0.0.1:8000/build'
text = 'E -> E + E\nE -> E * E\nE -> id\n'
resp = requests.post(url, json={'grammar': text})
print('status', resp.status_code)
print(json.dumps(resp.json(), indent=2, ensure_ascii=False))
