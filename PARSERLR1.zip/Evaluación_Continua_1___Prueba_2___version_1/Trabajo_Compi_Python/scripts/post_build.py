import requests
import json

text = '''S -> if E then S
S -> if E then S else
S -> other
E -> true
E -> false
'''

url = "http://127.0.0.1:8000/build"
resp = requests.post(url, json={"grammar": text})
print('status', resp.status_code)
print(json.dumps(resp.json(), indent=2, ensure_ascii=False))
