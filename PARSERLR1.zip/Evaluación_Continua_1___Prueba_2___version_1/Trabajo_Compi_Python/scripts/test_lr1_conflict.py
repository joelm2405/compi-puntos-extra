from Trabajo_Compi_Python.api import build_lr1_from_text

text = '''S -> if E then S
S -> if E then S else
S -> other
E -> true
E -> false
'''

g, lr1 = build_lr1_from_text(text)
print('is_lr1 =', getattr(lr1, 'is_lr1', True))
print('conflicts:')
for c in lr1.conflicts:
    print('  ', c)
