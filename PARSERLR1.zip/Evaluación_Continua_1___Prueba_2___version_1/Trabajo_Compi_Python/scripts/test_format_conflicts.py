from Trabajo_Compi_Python.api import build_lr1_from_text, _format_conflicts

grammar = "E -> E + E\nE -> E * E\nE -> id\n"

g, lr1 = build_lr1_from_text(grammar)
print('is_lr1 =', lr1.is_lr1)
print('raw conflicts:')
for r in lr1.conflicts:
    print('  ', r)
print('\nformatted conflicts:')
for f in _format_conflicts(lr1):
    print('  ', f)
