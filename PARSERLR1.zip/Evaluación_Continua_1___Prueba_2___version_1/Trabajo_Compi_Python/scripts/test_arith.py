from Trabajo_Compi_Python.api import build_lr1_from_text
import json

text = '''E -> E + T
E -> T
T -> T * F
T -> F
F -> ( E )
F -> id
'''

g, lr1 = build_lr1_from_text(text)
print('States count:', len(lr1.states))
print('Is LR(1):', lr1.is_lr1)
print('\nConflicts (human friendly):')
if not lr1.conflicts:
    print('  (none)')
else:
    for c in lr1.conflicts:
        print('  ', c)

# Print a short summary of ACTION conflicts if any
print('\nACTION table conflicts (summary):')
action_conflicts = [c for c in lr1.conflicts if ('Shift/Reduce' in c or 'Reduce/Reduce' in c)]
if not action_conflicts:
    print('  (none)')
else:
    for c in action_conflicts:
        print('  ', c)

# Optional: dump number of transitions and GOTO entries
print('\nTransitions:', len(lr1.transitions))
print('GOTO entries:', len(lr1.GOTO))
